import '../styles/globals.scss';
import '../styles/Form.scss';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
